
--Creating a BookStoreTbl Table for Book Store DB
CREATE TABLE [BKS].BookStoreTbl (
	Id INT IDENTITY(1,1) PRIMARY KEY,
    Publisher NVARCHAR(255) NULL,
    Title NVARCHAR(255) NULL,
    AuthorLastName NVARCHAR(255) NULL,
    AuthorFirstName NVARCHAR(255) NULL,
    Price DECIMAL(6,2) NULL
);

drop table [BKS].BookStoreTbl


--Creating a Schema for Book Store DB
CREATE SCHEMA BKS


--Creating User-Defined Table for Bulk Save
CREATE TYPE [BKS].tblBookStore AS TABLE
(
    Id INT,
    Publisher NVARCHAR(255),
    Title NVARCHAR(255),
    AuthorLastName NVARCHAR(255),
    AuthorFirstName NVARCHAR(255),
    Price DECIMAL(6,2)
)
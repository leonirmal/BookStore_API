DECLARE @tblTypeBK [BKS].tblBookStore

--Inserting some records
INSERT INTO @tblTypeBK ([Publisher],[Title],[AuthorLastName],[AuthorFirstName],[Price])
VALUES ('Leo','title','lName','fName',1.02)
      ,('zLeo','atitle','zlName','afName',2.03)
      ,('yLeo','btitle','ylName','bfName',3.04)
      ,('xLeo','ctitle','xlName','cfName',4.05)
      ,('wLeo','dtitle','wlName','dfName',5.06)
      ,('vLeo','etitle','vlName','efName',6.07)
      ,('uLeo','ftitle','ulName','ffName',7.08)
      ,('tLeo','gtitle','tlName','gfName',8.09)


-- Executing procedure
EXEC [BKS].[SP_BULKSAVEBOOKS]  @tblTypeBK

Select * from [BKS].[BookStoreTbl]